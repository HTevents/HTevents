# Hackathon Planning Kit

This repository contains the hackathon planning kit jointly constructed by:
-	[Software and Societal Systems Department](https://s3d.cmu.edu/), School of Computer Science, Carnegie Mellon University, Pittsburgh, PA, USA
-	[Institute of Computer Science](https://www.cs.ut.ee/en), University of Tartu, Tartu, Estonia


[**Read our herbsleb-group’s hackathon planning kit**](https://hackathon-planning-kit.org/)


All contributions to this project will be released under the [Creative Commons Attribution-ShareAlike 4.0 International License](https://creativecommons.org/licenses/by-sa/4.0/). By submitting a pull request, you are agreeing to comply with this waiver of copyright interest. You are free to share and adapt the content here but you are required to give appropriate credit to the original content and share your content under the same lincense.
